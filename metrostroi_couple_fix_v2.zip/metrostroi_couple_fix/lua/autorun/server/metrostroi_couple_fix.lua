-- =============================================================================
-- Metrostroi Couple Fix v2
-- Фикс расцепленных вагонов после апрельского обновления GMod 2026
--
-- ПРИЧИНА ПРОБЛЕМЫ:
--   Апрельское обновление GMod сломало Entity PhysicsCollide хуки,
--   из-за чего ENT:StartTouch в gmod_train_couple перестал срабатывать.
--
-- ИСПРАВЛЕНИЯ v2:
--   - Убран race condition: вместо одного таймера на каждый вагон,
--     один общий таймер обходит ВСЕ сцепки на карте последовательно.
--   - Убрана проверка CanCouple() — она блокировала крайний вагон
--     из-за DeCoupleTimeout и прочих внутренних флагов.
--   - Увеличен радиус поиска.
--   - Повторные попытки если с первого раза не получилось.
-- =============================================================================

local COUPLE_DELAY    = 0.5   -- задержка после последнего заспавненного вагона
local SEARCH_RADIUS   = 60    -- радиус поиска партнёра (юниты GMod)
local MAX_RETRIES     = 5     -- максимум повторных попыток для упрямого вагона
local RETRY_INTERVAL  = 0.4   -- интервал между повторными попытками
local DEBUG_LOG       = true

local function Log(msg)
    if DEBUG_LOG then
        print("[MetrostroiCoupleFix] " .. tostring(msg))
    end
end

-- Таймер перезапускается при каждом новом вагоне,
-- чтобы сработать только ПОСЛЕ того как весь состав заспавнен.
local pendingTimer = "MetrostroiCoupleFix_BatchTimer"

-- =============================================================================
-- Поиск партнёра для сцепки — без проверки CanCouple,
-- только геометрия: расстояние и направление.
-- =============================================================================
local function FindPartner(coupler)
    if not IsValid(coupler) then return nil end

    local myOffset = coupler.CouplingPointOffset or Vector(65, 0, 0)
    local myPos    = coupler:LocalToWorld(myOffset)
    local myFwd    = coupler:GetForward()
    local myTrain  = coupler:GetNW2Entity("TrainEntity")

    local best     = nil
    local bestDist = SEARCH_RADIUS * SEARCH_RADIUS

    for _, ent in ipairs(ents.FindInSphere(myPos, SEARCH_RADIUS)) do
        if IsValid(ent)
            and ent ~= coupler
            and ent:GetClass() == "gmod_train_couple"
            and ent.CoupledEnt == nil  -- партнёр ещё не сцеплен
        then
            local entTrain = ent:GetNW2Entity("TrainEntity")
            if entTrain ~= myTrain then  -- принадлежат разным вагонам
                local entOffset = ent.CouplingPointOffset or Vector(65, 0, 0)
                local entPos    = ent:LocalToWorld(entOffset)
                local distSqr   = myPos:DistToSqr(entPos)
                -- смотрят в противоположные стороны (dot < -0.4)
                local facing    = myFwd:Dot(ent:GetForward()) < -0.4

                if distSqr < bestDist and facing then
                    bestDist = distSqr
                    best = ent
                end
            end
        end
    end

    return best
end

-- =============================================================================
-- Прямая сцепка двух coupler-энтити, минуя все проверки CanCouple.
-- Повторяет логику ENT:Couple из gmod_train_couple/init.lua,
-- но без проверок таймаутов и флагов.
-- =============================================================================
local function ForceCouple(c1, c2)
    if not IsValid(c1) or not IsValid(c2) then return false end
    if c1.CoupledEnt ~= nil or c2.CoupledEnt ~= nil then return false end

    -- Сбрасываем таймаут расцепки чтобы Weld мог создаться
    c1.DeCoupleTime = 0
    c2.DeCoupleTime = 0

    -- Вызываем оригинальный Couple — он сам поставит позиции и создаст Weld
    c1:Couple(c2)

    -- Проверяем результат
    if c1.CoupledEnt == c2 then
        Log("Сцеплено: " .. tostring(c1) .. " <-> " .. tostring(c2))
        return true
    end

    return false
end

-- =============================================================================
-- Обход ВСЕХ незакреплённых сцепок на карте и попытка их сцепить.
-- Запускается один раз после того как весь состав заспавнен.
-- =============================================================================
local function FixAllCouplers()
    local tried   = 0
    local success = 0

    -- Собираем все незакреплённые сцепки
    for _, coupler in ipairs(ents.FindByClass("gmod_train_couple")) do
        if IsValid(coupler) and coupler.CoupledEnt == nil then
            tried = tried + 1
            local partner = FindPartner(coupler)
            if IsValid(partner) then
                if ForceCouple(coupler, partner) then
                    success = success + 1
                end
            end
        end
    end

    if tried > 0 then
        Log(string.format("Обработано сцепок: %d, успешно: %d", tried, success))
    end

    return success, tried
end

-- =============================================================================
-- Повторные попытки для упрямых сцепок.
-- Запускается если после первого прохода остались незакреплённые.
-- =============================================================================
local function ScheduleRetries()
    local attempt = 0
    local function retry()
        attempt = attempt + 1

        -- Считаем сколько ещё осталось незакреплённых
        local uncoupled = 0
        for _, c in ipairs(ents.FindByClass("gmod_train_couple")) do
            if IsValid(c) and c.CoupledEnt == nil then
                uncoupled = uncoupled + 1
            end
        end

        if uncoupled == 0 then
            Log("Все сцепки закреплены после " .. attempt .. " попыток.")
            return
        end

        Log(string.format("Попытка %d: осталось незакреплённых сцепок: %d", attempt, uncoupled))
        FixAllCouplers()

        if attempt < MAX_RETRIES then
            timer.Simple(RETRY_INTERVAL, retry)
        else
            Log("Достигнут лимит попыток (" .. MAX_RETRIES .. "). Оставшиеся сцепки не найдены.")
        end
    end

    timer.Simple(RETRY_INTERVAL, retry)
end

-- =============================================================================
-- Хук на создание вагонов.
-- Каждый новый вагон перезапускает общий батч-таймер.
-- Таймер срабатывает только когда вагоны перестают создаваться.
-- =============================================================================
hook.Add("OnEntityCreated", "MetrostroiCoupleFix_OnEntityCreated", function(ent)
    if not IsValid(ent) then return end
    if not string.StartWith(ent:GetClass(), "gmod_subway_") then return end

    -- Перезапускаем таймер — он сработает через COUPLE_DELAY
    -- после ПОСЛЕДНЕГО созданного вагона
    timer.Create(pendingTimer, COUPLE_DELAY, 1, function()
        Log("Запускаю проверку сцепок...")
        local ok, total = FixAllCouplers()

        -- Если не все сцепились — запускаем повторные попытки
        if ok < total then
            ScheduleRetries()
        end
    end)
end)

-- =============================================================================
-- Консольная команда для ручного запуска фикса.
-- Использование в консоли: metrostroi_fix_couples
-- =============================================================================
concommand.Add("metrostroi_fix_couples", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then
        ply:ChatPrint("[MetrostroiCoupleFix] Только для администраторов!")
        return
    end

    Log("Ручной запуск фикса...")
    FixAllCouplers()
    ScheduleRetries()

    if IsValid(ply) then
        ply:ChatPrint("[MetrostroiCoupleFix] Запущено! Смотри консоль сервера.")
    end
end, nil, "Принудительно сцепить все расцепленные вагоны на карте", FCVAR_PROTECTED)

Log("Фикс v2 загружен. April 2026 GMod Update fix.")
